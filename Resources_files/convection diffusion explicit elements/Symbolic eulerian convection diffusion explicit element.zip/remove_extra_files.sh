#!/usr/bin/env bash

rm *.aux
rm *.auxlock
rm *.bbl
rm *.blg
rm *.log
rm *.out
rm *.synctex.gz
