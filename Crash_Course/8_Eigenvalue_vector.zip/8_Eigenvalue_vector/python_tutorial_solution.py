import KratosMultiphysics as Kratos
import KratosMultiphysics.StructuralMechanicsApplication as KratosSMA
import KratosMultiphysics.LinearSolversApplication as KratosLSA
import KratosMultiphysics.KratosUnittest as KratosUnittest
from KratosMultiphysics import eigen_solver_factory

####################################################################
## Model creation

# model part
model = Kratos.Model()
model_part = model.CreateModelPart("Eigen_Q4_Thick_2x2_Plate_test")
model_part.SetBufferSize(1)
model_part.ProcessInfo.SetValue(Kratos.DOMAIN_SIZE, 3)
model_part.AddNodalSolutionStepVariable(Kratos.DISPLACEMENT)
model_part.AddNodalSolutionStepVariable(Kratos.REACTION)
model_part.AddNodalSolutionStepVariable(Kratos.ROTATION)
model_part.AddNodalSolutionStepVariable(Kratos.REACTION_MOMENT)

# nodes
model_part.CreateNewNode(1, 0.0, 1.0, 0.0)
model_part.CreateNewNode(2, 0.0, 0.5, 0.0)
model_part.CreateNewNode(3, 0.0, 0.0, 0.0)
model_part.CreateNewNode(4, 1.0, 1.0, 0.0)
model_part.CreateNewNode(5, 1.0, 0.5, 0.0)
model_part.CreateNewNode(6, 1.0, 0.0, 0.0)
model_part.CreateNewNode(7, 2.0, 1.0, 0.0)
model_part.CreateNewNode(8, 2.0, 0.5, 0.0)
model_part.CreateNewNode(9, 2.0, 0.0, 0.0)

for node in model_part.Nodes:
    node.AddDof(Kratos.DISPLACEMENT_X, Kratos.REACTION_X)
    node.AddDof(Kratos.DISPLACEMENT_Y, Kratos.REACTION_Y)
    node.AddDof(Kratos.DISPLACEMENT_Z, Kratos.REACTION_Z)
    node.AddDof(Kratos.ROTATION_X, Kratos.REACTION_MOMENT_X)
    node.AddDof(Kratos.ROTATION_Y, Kratos.REACTION_MOMENT_Y)
    node.AddDof(Kratos.ROTATION_Z, Kratos.REACTION_MOMENT_Z)

# boundary conditions
sub_model_part = model_part.CreateSubModelPart("support")
sub_model_part.AddNodes([1,2,3,4,6,7,8,9])

for node in sub_model_part.Nodes:
    node.Fix(Kratos.DISPLACEMENT_X)
    node.Fix(Kratos.DISPLACEMENT_Y)
    node.Fix(Kratos.DISPLACEMENT_Z)

# materials
cl = Kratos.KratosGlobals.GetConstitutiveLaw("LinearElasticPlaneStress2DLaw").Clone()
model_part.GetProperties()[0].SetValue(Kratos.CONSTITUTIVE_LAW, cl)
model_part.GetProperties()[0].SetValue(Kratos.YOUNG_MODULUS, 1.0e7)
model_part.GetProperties()[0].SetValue(Kratos.POISSON_RATIO, 0.29)
model_part.GetProperties()[0].SetValue(Kratos.DENSITY, 7850)
model_part.GetProperties()[0].SetValue(Kratos.THICKNESS, 0.1)
model_part.GetProperties()[0].SetValue(Kratos.COMPUTE_LUMPED_MASS_MATRIX, True)

# elements
model_part.CreateNewElement("ShellThickElement3D4N", 1, [8, 7, 4, 5], model_part.GetProperties()[0])
model_part.CreateNewElement("ShellThickElement3D4N", 2, [9, 8, 5, 6], model_part.GetProperties()[0])
model_part.CreateNewElement("ShellThickElement3D4N", 3, [2, 3, 6, 5], model_part.GetProperties()[0])
model_part.CreateNewElement("ShellThickElement3D4N", 4, [2, 5, 4, 1], model_part.GetProperties()[0])

####################################################################
## Solve

eigensolver_settings = Kratos.Parameters("""
    {
        "eigen_system_settings" : {
                "solver_type"       : "spectra_sym_g_eigs_shift",
                "number_of_eigenvalues": 1,
                "max_iteration": 1000,
                "echo_level": 4
            }
    }
    """)

solution_scheme = KratosSMA.EigensolverDynamicScheme()
eigen_linear_solver = eigen_solver_factory.ConstructSolver(eigensolver_settings["eigen_system_settings"])
builder_and_solver = Kratos.ResidualBasedBlockBuilderAndSolver(eigen_linear_solver)
strategy = KratosSMA.EigensolverStrategy(model_part, solution_scheme, builder_and_solver, 0.0, 1.0)
strategy.Solve()

####################################################################
## Example of KRATOS Processes: adapted from check_eigenvalues_process.py in StructuralMechanicsApplication) 

def Factory(settings, model):
    if not isinstance(settings, Kratos.Parameters):
        raise Exception("expected input shall be a Parameters object, encapsulating a json string")
    return CheckEigenValueProcess(model, settings["Parameters"])

# all the processes python should be derived from "Process"
class CheckEigenValueProcess(Kratos.Process, KratosUnittest.TestCase):
    def __init__(self, model, settings):
        default_settings = Kratos.Parameters(
            """
            {
                "help"            :"This process checks the solution obtained in a eigenvalue problem.",
                "model_part_name" : "Structure",
                "variable_name"   : "EIGENVALUE_VECTOR",
                "reference_values": "[1.,2.,3.]"
            }
            """
        );

        settings.ValidateAndAssignDefaults(default_settings)

        Kratos.Process.__init__(self)
        self.model_part = model[settings["model_part_name"].GetString()]
        self.variable = Kratos.KratosGlobals.GetVariable(settings["variable_name"].GetString())
        self.reference_values = []
        reference_values = settings["reference_values"].GetString()
        for ev in reference_values.strip('[]').split(','):
            self.reference_values.append(float(ev))


    # executed at the begining to initialize the process
    def ExecuteInitialize(self):
        pass
    
    # verifies that the input is correct
    def Check(self):
        pass
    
    # executed just before the solution-loop
    def ExecuteBeforeSolutionLoop(self):
        pass
    
    # executed in order to initialize the current step
    def ExecuteInitializeSolutionStep(self):
        pass

    # executed before writing the output
    def ExecuteBeforeOutputStep(self):
        pass
    
    # executed after writing the output
    def ExecuteAfterOutputStep(self):
        pass
    
    # executed in order to finalize the current step
    def ExecuteFinalizeSolutionStep(self):
        pass

    # executed after the computations, at the end of the solution-loop
    def ExecuteFinalize(self):
        current_values = [ev for ev in self.model_part.ProcessInfo[self.variable]]
        print("Curent values:", current_values)
        print("Reference values:", self.reference_values)
        for evs in zip(current_values,self.reference_values):
            self.assertAlmostEqual(evs[0],evs[1],5)
            
        
####################################################################
## test processes

custom_settings = Kratos.Parameters("""
        {
                "model_part_name" : "Eigen_Q4_Thick_2x2_Plate_test",
                "variable_name"   : "EIGENVALUE_VECTOR",
                "reference_values": "[88.96614452367326]"
            }
        """)

test_process = CheckEigenValueProcess(model,custom_settings)
test_process.ExecuteFinalize()

####################################################################
