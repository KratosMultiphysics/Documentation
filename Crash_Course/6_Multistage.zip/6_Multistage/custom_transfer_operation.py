import KratosMultiphysics

class CustomTransferOperation(KratosMultiphysics.Operation):

    def __init__(self, Model, Settings):
        KratosMultiphysics.Operation.__init__(self)

        self.model = Model
        self.input_model_part_name = Settings["input_model_part_name"].GetString()
        self.output_model_part_name = Settings["output_model_part_name"].GetString()

    def Execute(self):

        input_model_part = self.model.GetModelPart(self.input_model_part_name)
        output_model_part = self.model.GetModelPart(self.output_model_part_name)

        for node_in, node_out in zip(input_model_part.Nodes, output_model_part.Nodes):
            velocity = node_in.GetSolutionStepValue(KratosMultiphysics.VELOCITY, 0)
            node_out.SetSolutionStepValue(KratosMultiphysics.VELOCITY, 0, velocity)
