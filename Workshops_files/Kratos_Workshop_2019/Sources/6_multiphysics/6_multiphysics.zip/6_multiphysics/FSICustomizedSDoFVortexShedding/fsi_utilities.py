#===============================================================================
'''
Project:Lecture - Structural Wind Engineering WS18-19 
        Chair of Structural Analysis @ TUM - R. Wuchner, M. Pentek
        
        FSI utilities

Author: philipp.bucher@tum.de, a.winterstein@tum.de, mate.pentek@tum.de, anoop.kodakkal@tum.de
      
Note: ...

Created on:  16.01.2018
Last update: 13.11.2018
'''
#===============================================================================

import KratosMultiphysics
import KratosMultiphysics.StructuralMechanicsApplication as KratosStructuralMechanics

import sys
import time
import math


'''
Additionals functionalities to make the FSI possible
This would otherwise be done by the EmpireApplication
or the FSIApplication
'''


def Norm(array):
    '''
    Return the L2 norm
    '''
    norm = 0
    for row in array:
        try:    # array is a matrix
            for entry in row:
                norm += entry**2
        except: # array is a vector
            norm += row**2
    return pow(norm,0.5)   

def GetDisplacements(structure_solver):
    return structure_solver.GetDisplacement()

def SetDisplacements(displacements, structure_solver):
    return structure_solver.SetDisplacement(displacements)

def NeumannToStructure(mapper, structure_solver, flag):
    
    multiplicator = 1.0
    if flag:
        multiplicator = -1.0

    f = 0.0
    if structure_solver.dof_type == "DISPLACEMENT_X":
        for node in mapper.destination_interface.Nodes:    
            f += multiplicator * node.GetSolutionStepValue(KratosMultiphysics.REACTION_X, 0)
    if structure_solver.dof_type == "DISPLACEMENT_Y":
        for node in mapper.destination_interface.Nodes:
            f += multiplicator * node.GetSolutionStepValue(KratosMultiphysics.REACTION_Y, 0)
    
    structure_solver.SetExternalForce(f)

def DisplacementToMesh(mapper, displacement, structure_solver):     

    if structure_solver.dof_type == "DISPLACEMENT_X":
        for node in mapper.destination_interface.Nodes:
            node.SetSolutionStepValue(KratosMultiphysics.MESH_DISPLACEMENT_X, displacement)
            
    if structure_solver.dof_type == "DISPLACEMENT_Y":
        for node in mapper.destination_interface.Nodes:
            node.SetSolutionStepValue(KratosMultiphysics.MESH_DISPLACEMENT_Y, displacement)
   

'''
Additional functionalities to create here a custom convergence accelerator
This would otherwise be done by the EmpireApplication
'''


def CreateConvergenceAccelerator(convergence_accelerator_settings):
    if convergence_accelerator_settings["type"].GetString() == "aitken":
        return AitkenConvergenceAccelerator(convergence_accelerator_settings)
    else:
        raise Exception("the requested convergence accelerator type " + convergence_accelerator_settings["type"].GetString() + "is not implemented.")

class ConvergenceAcceleratorBase(object):
    def __init__(self, convergence_accelerator_settings):
        self.max_iter = convergence_accelerator_settings["max_iterations"].GetInt()
        self.res_rel_tol = convergence_accelerator_settings["residual_relative_tolerance"].GetDouble()
        self.res_abs_tol = convergence_accelerator_settings["residual_absolute_tolerance"].GetDouble()
        self.rel_coef_initial = convergence_accelerator_settings["relaxation_coefficient_initial_value"].GetDouble()

    def CalculateResidual(self, solution, old_solution):
        '''
        Calculates the residual based upon the (current) solution
        and the old one
        '''
        residual = [0.0] * len(solution)
        for index in range(len(solution)):
            residual[index] = solution[index] - old_solution[index]
        return residual

    def CalculateRelaxedSolution(self, relaxation_coefficient, old_solution, residual):
        '''
        Calculates the relaxed (i.e. new) solution
        '''
        for index in range(len(old_solution)):
            old_solution[index] = old_solution[index] + relaxation_coefficient * residual[index]
        return old_solution # this is the relaxed new solution

    def ComputeRelaxationCoefficient(self):
        print("Function needs to be implemented in the derived class")

class AitkenConvergenceAccelerator(ConvergenceAcceleratorBase):
    def ComputeRelaxationCoefficient(self, old_coefficient, residual, old_residual, iteration, max_initial_coefficient=0.2, upper_limit=2.5, lower_limit=-0.5):
        if iteration < 1:
            new_coefficient = min(old_coefficient, max_initial_coefficient)
        else:
            numerator = 0
            denominator = 0
            for i in range(len(residual)):
                numerator += old_residual[i] * (residual[i] - old_residual[i])
                denominator += pow(residual[i]-old_residual[i],2)
            new_coefficient = - old_coefficient * (numerator/denominator)
            
            # force some limit on the calculated coefficient
            if new_coefficient > upper_limit:
                new_coefficient = upper_limit
                print("WARNING: upper limit of " + str(upper_limit) + "reached in Aitken: ComputeCustomRelaxation()")
            elif new_coefficient < lower_limit:
                new_coefficient = lower_limit
                print("WARNING: lower limit of " + str(lower_limit) + "reached in Aitken: ComputeCustomRelaxation()")
        return new_coefficient


'''
Additional functionalities to create here a custom mapper
This would otherwise be done by the MappingApplication
'''

def CreateMapper(destination_model_part, mapper_settings):
    return CustomMapper(destination_model_part, mapper_settings)

class CustomMapper(object):
    # def __init__(self, destination_model_part, origin_model_part, mapper_settings):
    def __init__(self, destination_model_part, mapper_settings):
        # here DESTINATION = interface nodes on FLUID
        destination_interface_name = mapper_settings["interface_submodel_part_destination"].GetString()
        self.destination_interface = destination_model_part.GetSubModelPart(destination_interface_name)