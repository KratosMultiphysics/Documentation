from __future__ import print_function, absolute_import, division #makes KratosMultiphysics backward compatible with python 2.6 and 2.7

import KratosMultiphysics
from KratosMultiphysics.StructuralMechanicsApplication.structural_mechanics_analysis import StructuralMechanicsAnalysis

"""
For user-scripting it is intended that a new class is derived
from StructuralMechanicsAnalysis to do modifications
"""

class StructuralMechanicsAnalysisPrintReactions(StructuralMechanicsAnalysis):
    def __init__(self, model, project_parameters):
        super(StructuralMechanicsAnalysis, self).__init__(model, project_parameters)
        print("Constructor CUSTOM")

    def ModifyInitialProperties(self):
        """this is the place to eventually modify material properties in the stage """
        super(StructuralMechanicsAnalysis, self).ModifyInitialProperties()

        model_part = self.model["Structure"]
        structural_properties = self.model["Structure"].GetProperties()[1]
        structural_properties[KratosMultiphysics.THICKNESS] = 0.2

    def ModifyInitialGeometry(self):
        """this is the place to eventually modify geometry (for example moving nodes) in the stage """
        super(StructuralMechanicsAnalysis, self).ModifyInitialGeometry()

        # Now we apply a point load. In order for it to get assembled into the RHS of the system,
        # we have to create also the corresponding conditions (PointLoadCondition):

        computing_model_part = self.model["Structure.computing_domain"]

        condition_name = "PointLoadCondition2D1N"
        condition_property = computing_model_part.GetProperties()[0]

        condition_start_id = computing_model_part.NumberOfConditions() + 1

        for counter, node in enumerate(computing_model_part.Nodes):
            condition_connectivity = [ node.Id ]
            condition_id = counter + condition_start_id
            computing_model_part.CreateNewCondition(condition_name, condition_id, condition_connectivity, condition_property)

    def FinalizeSolutionStep(self):
        super(StructuralMechanicsAnalysis, self).FinalizeSolutionStep()

        reaction_x = 0.0
        reaction_y = 0.0
        for node in self.model["Structure.DISPLACEMENT_Ground"].Nodes:
            reaction_x += node.GetSolutionStepValue(KratosMultiphysics.REACTION_X)
            reaction_y += node.GetSolutionStepValue(KratosMultiphysics.REACTION_Y)

        print("REACTION X:", reaction_x)
        print("REACTION Y:", reaction_y)


if __name__ == "__main__":

    with open("ProjectParameters.json",'r') as parameter_file:
        parameters = KratosMultiphysics.Parameters(parameter_file.read())

    model = KratosMultiphysics.Model()
    simulation = StructuralMechanicsAnalysisPrintReactions(model,parameters)
    simulation.Run()
