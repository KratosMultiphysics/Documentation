import KratosMultiphysics as KM

def Factory(settings, model):
    if not isinstance(settings, KM.Parameters):
        raise Exception("expected input shall be a Parameters object, encapsulating a json string")
    return ComputeReactionProcess(model, settings["Parameters"])

# All the processes python should be derived from "Process"
class ComputeReactionProcess(KM.Process):
    """This process computes the sum of reactions on a ModelPart

    Public member variables:
    model -- the container of the different model parts.
    settings -- Kratos parameters containing process settings.
    """

    def __init__(self, model, settings ):
        """ The default constructor of the class

        Keyword arguments:
        self -- It signifies an instance of a class.
        Model -- the container of the different model parts.
        settings -- Kratos parameters containing process settings.
        """
        KM.Process.__init__(self) # calling the baseclass constructor

        default_settings = KM.Parameters("""{
            "model_part_name"                 : "UNSPECIFIED",
            "variable_name"                   : "REACTION",
            "print_reaction_values_to_screen" : false
        }""")

        # Add missing settings that the user did not provide but that
        # are necessary for this process
        settings.ValidateAndAssignDefaults(default_settings)
        # Alternative:
        # settings.RecursivelyValidateAndAssignDefaults(default_settings)

        # saving the modelpart
        model_part_name = settings["model_part_name"].GetString()
        self.model_part = model[settings["model_part_name"].GetString()]

        # saving the reaction-variable
        reaction_variable_name = settings["variable_name"].GetString()
        self.reaction_variable_x = KM.KratosGlobals.GetVariable(reaction_variable_name+"_X")
        self.reaction_variable_y = KM.KratosGlobals.GetVariable(reaction_variable_name+"_Y")
        self.reaction_variable_z = KM.KratosGlobals.GetVariable(reaction_variable_name+"_Z")

        # saving whether the reactions should be printed in the terminal
        self.print_reactions = settings["print_reaction_values_to_screen"].GetBool()

    def ExecuteFinalizeSolutionStep(self):
        """ This method is executed in order to finalize the current step

        Keyword arguments:
        self -- It signifies an instance of a class.
        """

        reaction_x = 0.0
        reaction_y = 0.0
        reaction_z = 0.0
        for node in self.model_part.Nodes:
            reaction_x += node.GetSolutionStepValue(self.reaction_variable_x)
            reaction_y += node.GetSolutionStepValue(self.reaction_variable_y)
            reaction_z += node.GetSolutionStepValue(self.reaction_variable_z)

        if self.print_reactions:
            print("REACTION X:", reaction_x)
            print("REACTION Y:", reaction_y)
            print("REACTION Z:", reaction_z)

        # Optional: print values to file

